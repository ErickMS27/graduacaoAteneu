package Algoritmos.NP2.src;

public class test {

    public static void main(String[] args) {

    }

}
